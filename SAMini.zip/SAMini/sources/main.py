from globaldata import *
class Node:

   def __init__(self,data,nextNode=None):
       self.data = data
       self.nextNode = nextNode

   def getData(self):
       return self.data

   def setData(self,val):
       self.data = val

   def getNextNode(self):
       return self.nextNode

   def setNextNode(self,val):
       self.nextNode = val

class LinkedList:

   def __init__(self,head = None):
       self.head = head
       self.size = 0
       self.engine = pyttsx3.init()

   def getSize(self):
       return self.size

   def addNode(self,data):
       newNode = Node(data,self.head)
       self.head = newNode
       self.size+=1
       return True
       
   def printNode(self):
    if self.head is None:
      print("Attendance list Empty!")
      self.engine.say("Attendance list Empty!")
      self.engine.runAndWait()
    curr = self.head
    while curr:
        print(curr.data)
        filename = str(datetime.datetime.now().strftime("%Y%m%d"))+".txt"
        f = open("logs/"+filename, 'a')
        f.write(curr.data+"\n")
        f.close()
        curr = curr.getNextNode()

myList = LinkedList()
engine = pyttsx3.init()


def addAttendance():
  subject = input("Enter the subject for which you want to Assign Attendance!\n")
  count = int(input("Enter How many Record You want to Assign?\n"))
 
  for i in range(0,count):
    usn = input("Enter Student USN->")
    time = datetime.datetime.now().strftime("%H:%M:%S %p")
    myList.addNode(studentData[usn].lower()+"\t\t"+uniquecode+usn+" \t"+currentDate+" \t"+subject+" \t"+time)
    time = ""



def showAttendance():
  myList.printNode()


def getTotal():
  print("Total No. of Record Added is "+str(myList.getSize()))
  engine.say("Total Number of Record Added is "+str(myList.getSize()))
  engine.runAndWait()



def showlogs():
  filename = str(datetime.datetime.now().strftime("%Y%m%d"))+".txt"
  try:
    print("Logs for "+currentDate+"\n")

    f = open("logs/"+filename, 'r')
    print(f.read())
    f.close()
  except:
    print("No Logs Found for Today")
    engine.say("No Logs Found for Today")
    engine.runAndWait()


def showprevlogs():
  getDays = int(input("How many days Record You want to be? \n"))
  day = timedelta(days=getDays)
  prevDays=datetime.datetime.now()-day
  filename = str(prevDays.strftime("%Y%m%d"))+".txt"
  try:
    print(f' Logs for {prevDays.strftime("%d-%b-%Y")} are below:\n ')
    f = open("logs/"+filename, 'r')
    print(f.read())
    f.close()
  except:
    print(f'Attendance Logs for '+prevDays.strftime("%d-%b-%Y")+' not  available!')
    engine.say("Attendance Logs for "+prevDays.strftime("%d-%b-%Y")+"not available!")
    engine.runAndWait()



  
def main():
  print()
  print()
  print("Choose an option!\n")
  print("1.Assign Attendance!")
  print("2.Generate & Display Attendance!")
  print("3.Read Today Logs!")
  print("4.Display Previous Days Attendance!")
  print("5.Total No. of Student attendance Given!")
  print("6.Exit\n")
  choice=input(">")
  print()
  if choice=="1":
    addAttendance()
  elif choice == "2":
    showAttendance()
  elif choice =="3":
    showlogs()
  elif choice == "4":
    showprevlogs()
  elif choice == "5":
    getTotal()
  elif choice == "6":
    greetings = ["Have a nice day","Take care","Nice to meet you","Bye","Bye Bye","See you later"]
    greet = greetings[random.randint(1,len(greetings)-1)]
    '''
    exit()'''
    print("Are you sure to exit?\n")
    print("Y for yes & N for No")
    yesorno = input("").upper()
    if yesorno == "y".upper() or yesorno == "yes".upper():
      print(" "*40+greet)
      engine.say(greet)
      engine.runAndWait()
      exit()
    elif yesorno == "n".upper() or yesorno == "no".upper():
      main()
    else:
      print("Invalid Response");
      engine.say("Invalid Response")
      engine.say("Try Again!")
      engine.runAndWait()



  else:
    print("You choose an invalid option!");
    engine.say("You choose an invalid option!")
    engine.say("Try Again!")
    engine.runAndWait()

  main()

main()