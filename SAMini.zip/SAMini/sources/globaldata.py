import datetime
import json
import pyttsx3
import random
from datetime import timedelta

# All Global Data

studentData = json.loads(open('data.json').read())
uniquecode = '1MV18IS'
year = str(datetime.datetime.now().strftime("%Y"))
weekday = str(datetime.datetime.now().strftime("%A"))
dayno = str(datetime.datetime.now().strftime("%d"))
month = str(datetime.datetime.now().strftime("%b"))
currentDate = dayno+"-"+month+"-"+year
time = ""
